"""Test package initializer to make unittest discovery work reliably."""
